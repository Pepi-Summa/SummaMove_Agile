-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 05, 2026 at 05:56 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `summamovedatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `challenges`
--

CREATE TABLE `challenges` (
  `ID` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Description` text DEFAULT NULL,
  `Difficulty` enum('Easy','Medium','Hard') NOT NULL,
  `Point_Reward` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `challenges`
--

INSERT INTO `challenges` (`ID`, `Name`, `Description`, `Difficulty`, `Point_Reward`) VALUES
(1, 'Drink Water', 'Drink 2 liters of water today', 'Easy', 50),
(2, 'Morning Run', 'Run 5km before noon', 'Medium', 150),
(3, '10K Steps', 'Walk 10.000 steps in one day', 'Hard', 300),
(4, 'Drink Water', 'Drink 2 liters of water today', 'Easy', 50),
(5, 'Morning Run', 'Run 5km before noon', 'Medium', 150),
(6, '10K Steps', 'Walk 10.000 steps in one day', 'Hard', 300),
(7, 'Drink Water', 'Drink 2 liters of water today', 'Easy', 50),
(8, 'Morning Run', 'Run 5km before noon', 'Medium', 150),
(9, '10K Steps', 'Walk 10.000 steps in one day', 'Hard', 300);

-- --------------------------------------------------------

--
-- Table structure for table `friends`
--

CREATE TABLE `friends` (
  `ID` int(11) NOT NULL,
  `User_ID` int(11) NOT NULL,
  `Friend_ID` int(11) NOT NULL,
  `Status` enum('Pending','Accepted','Blocked') DEFAULT 'Pending',
  `Created_At` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `friends`
--

INSERT INTO `friends` (`ID`, `User_ID`, `Friend_ID`, `Status`, `Created_At`) VALUES
(1, 1, 2, 'Accepted', '2026-06-05 05:46:04'),
(2, 1, 3, '', '2026-06-05 05:46:04'),
(3, 2, 4, 'Blocked', '2026-06-05 05:46:04');

-- --------------------------------------------------------

--
-- Table structure for table `leaderboard_entries`
--

CREATE TABLE `leaderboard_entries` (
  `ID` int(11) NOT NULL,
  `User_ID` int(11) NOT NULL,
  `Points` int(11) NOT NULL,
  `Rank_Position` int(11) NOT NULL,
  `Period_Type` enum('Daily','Weekly','Monthly','All_Time') NOT NULL,
  `Created_At` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `leaderboard_entries`
--

INSERT INTO `leaderboard_entries` (`ID`, `User_ID`, `Points`, `Rank_Position`, `Period_Type`, `Created_At`) VALUES
(1, 1, 1200, 2, 'Weekly', '2026-06-05 05:45:06'),
(2, 2, 850, 3, 'Weekly', '2026-06-05 05:45:06'),
(3, 3, 2000, 1, 'Weekly', '2026-06-05 05:45:06'),
(4, 4, 450, 4, 'Weekly', '2026-06-05 05:45:06'),
(5, 1, 1200, 2, 'Weekly', '2026-06-05 05:46:04'),
(6, 2, 850, 3, 'Weekly', '2026-06-05 05:46:04'),
(7, 3, 2000, 1, 'Weekly', '2026-06-05 05:46:04'),
(8, 4, 450, 4, 'Weekly', '2026-06-05 05:46:04');

-- --------------------------------------------------------

--
-- Table structure for table `store_items`
--

CREATE TABLE `store_items` (
  `ID` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Product_Type` enum('BG_Theme','Lettertype','Player_Title') NOT NULL,
  `Cost` int(11) NOT NULL,
  `Description` text DEFAULT NULL,
  `Preview_Image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `store_items`
--

INSERT INTO `store_items` (`ID`, `Name`, `Product_Type`, `Cost`, `Description`, `Preview_Image`) VALUES
(1, 'Dark Theme', '', 0, NULL, NULL),
(2, 'Retro Font', 'Lettertype', 0, NULL, NULL),
(3, 'Champion', '', 0, NULL, NULL),
(4, 'Dark Theme', '', 0, NULL, NULL),
(5, 'Retro Font', 'Lettertype', 0, NULL, NULL),
(6, 'Champion', '', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `ID` int(11) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Password_Hash` varchar(255) NOT NULL,
  `Points` int(11) DEFAULT 0,
  `Account_Created` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `Username`, `Email`, `Password_Hash`, `Points`, `Account_Created`) VALUES
(1, 'Daan', 'daan@email.com', 'test123', 5, '2026-06-05 05:30:48'),
(2, 'Lisa', 'lisa@email.com', 'qwerty', 3, '2026-06-05 05:30:48'),
(3, 'Mike', 'mike@email.com', 'welcome1', 8, '2026-06-05 05:30:48'),
(4, 'Emma', 'emma@email.com', 'password', 2, '2026-06-05 05:30:48');

-- --------------------------------------------------------

--
-- Table structure for table `user_challenges`
--

CREATE TABLE `user_challenges` (
  `ID` int(11) NOT NULL,
  `User_ID` int(11) NOT NULL,
  `Challenge_ID` int(11) NOT NULL,
  `Completed` tinyint(1) DEFAULT 0,
  `Completed_At` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_challenges`
--

INSERT INTO `user_challenges` (`ID`, `User_ID`, `Challenge_ID`, `Completed`, `Completed_At`) VALUES
(1, 1, 1, 1, '2026-06-05 05:44:46'),
(2, 1, 2, 0, NULL),
(3, 2, 3, 1, '2026-06-05 05:44:46'),
(4, 3, 2, 0, NULL),
(5, 1, 1, 1, '2026-06-05 05:45:06'),
(6, 1, 2, 0, NULL),
(7, 2, 3, 1, '2026-06-05 05:45:06'),
(8, 3, 2, 0, NULL),
(9, 1, 1, 1, '2026-06-05 05:46:04'),
(10, 1, 2, 0, NULL),
(11, 2, 3, 1, '2026-06-05 05:46:04'),
(12, 3, 2, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_items`
--

CREATE TABLE `user_items` (
  `ID` int(11) NOT NULL,
  `User_ID` int(11) NOT NULL,
  `Store_Item_ID` int(11) NOT NULL,
  `Purchased_At` datetime DEFAULT current_timestamp(),
  `Is_Equipped` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_items`
--

INSERT INTO `user_items` (`ID`, `User_ID`, `Store_Item_ID`, `Purchased_At`, `Is_Equipped`) VALUES
(1, 1, 1, '2026-06-05 05:45:06', 1),
(2, 1, 3, '2026-06-05 05:45:06', 0),
(3, 2, 2, '2026-06-05 05:45:06', 1),
(4, 3, 1, '2026-06-05 05:45:06', 0),
(5, 1, 1, '2026-06-05 05:46:04', 1),
(6, 1, 3, '2026-06-05 05:46:04', 0),
(7, 2, 2, '2026-06-05 05:46:04', 1),
(8, 3, 1, '2026-06-05 05:46:04', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `challenges`
--
ALTER TABLE `challenges`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `friends`
--
ALTER TABLE `friends`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `User_ID` (`User_ID`),
  ADD KEY `Friend_ID` (`Friend_ID`);

--
-- Indexes for table `leaderboard_entries`
--
ALTER TABLE `leaderboard_entries`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `User_ID` (`User_ID`);

--
-- Indexes for table `store_items`
--
ALTER TABLE `store_items`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `Username` (`Username`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indexes for table `user_challenges`
--
ALTER TABLE `user_challenges`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `User_ID` (`User_ID`),
  ADD KEY `Challenge_ID` (`Challenge_ID`);

--
-- Indexes for table `user_items`
--
ALTER TABLE `user_items`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `User_ID` (`User_ID`),
  ADD KEY `Store_Item_ID` (`Store_Item_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `challenges`
--
ALTER TABLE `challenges`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `friends`
--
ALTER TABLE `friends`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `leaderboard_entries`
--
ALTER TABLE `leaderboard_entries`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `store_items`
--
ALTER TABLE `store_items`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `user_challenges`
--
ALTER TABLE `user_challenges`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `user_items`
--
ALTER TABLE `user_items`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `friends`
--
ALTER TABLE `friends`
  ADD CONSTRAINT `friends_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `users` (`ID`),
  ADD CONSTRAINT `friends_ibfk_2` FOREIGN KEY (`Friend_ID`) REFERENCES `users` (`ID`);

--
-- Constraints for table `leaderboard_entries`
--
ALTER TABLE `leaderboard_entries`
  ADD CONSTRAINT `leaderboard_entries_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `users` (`ID`);

--
-- Constraints for table `user_challenges`
--
ALTER TABLE `user_challenges`
  ADD CONSTRAINT `user_challenges_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `users` (`ID`),
  ADD CONSTRAINT `user_challenges_ibfk_2` FOREIGN KEY (`Challenge_ID`) REFERENCES `challenges` (`ID`);

--
-- Constraints for table `user_items`
--
ALTER TABLE `user_items`
  ADD CONSTRAINT `user_items_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `users` (`ID`),
  ADD CONSTRAINT `user_items_ibfk_2` FOREIGN KEY (`Store_Item_ID`) REFERENCES `store_items` (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
